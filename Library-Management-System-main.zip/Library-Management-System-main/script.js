let searchInputEl = document.getElementById('searchInput');
let searchResultsContainer = document.getElementById('searchResults');
const spinner = document.getElementById('spinner');

// Function to create and append book results
function createAndAppendResults(results) {
    // Show the spinner while the results are loading
    spinner.classList.add('d-block');

    let { imageLink, author } = results;

    // Create a div for the book card
    let bookCard = document.createElement('div');
    bookCard.classList.add('col-12', 'col-sm-6', 'col-md-4', 'col-lg-2', 'book-card');

    // Create an image element for the book cover
    let imageEl = document.createElement('img');
    imageEl.src = imageLink;
    imageEl.alt = 'Book Cover';

    // Create a paragraph for the book author
    let headingAuthor = document.createElement('p');
    headingAuthor.textContent = author;

    // Append the image and author to the book card
    bookCard.appendChild(imageEl);
    bookCard.appendChild(headingAuthor);

    // Append the book card to the results container
    searchResultsContainer.appendChild(bookCard);
}

// Function to display results
function displayResults(search_results) {
    // Clear previous results
    searchResultsContainer.innerHTML = '';

    // Loop through the results and create the content
    for (let results of search_results) {
        createAndAppendResults(results);
    }

    // Hide the spinner once the results are displayed
    spinner.classList.remove('d-block');
}

// Function to handle search results when Enter key is pressed
function searchResultValue(event) {
    if (event.key === 'Enter') {
        let title = searchInputEl.value.trim();
        if (!title) {
            return; // If no title is entered, do nothing
        }

        console.log('Searching for: ' + title);

        // Show the spinner while data is being fetched
        spinner.classList.add('d-block');

        let options = { method: 'GET' };
        let url = "https://apis.ccbp.in/book-store?title=" + title;

        fetch(url, options)
            .then(function (response) {
                return response.json();
            })
            .then(function (jsonData) {
                let { search_results } = jsonData;

                // Display the results after data is fetched
                displayResults(search_results);
            })
            .catch(function (error) {
                console.error('Error fetching data:', error);
                spinner.classList.remove('d-block'); // Hide the spinner in case of an error
            });
    }
}

// Add event listener to the search input field to trigger search on 'Enter'
searchInputEl.addEventListener('keydown', searchResultValue);

// Function to fetch all books initially (optional, or you can adjust as needed)
function fetchAllBooks() {
    let url = "https://apis.ccbp.in/book-store";
    fetch(url)
        .then(function (response) {
            return response.json();
        })
        .then(function (jsonData) {
            let { search_results } = jsonData;
            displayResults(search_results);
        })
        .catch(function (error) {
            console.error('Error fetching all books:', error);
        });
}

// Call the function to fetch and display books on initial load
fetchAllBooks();
